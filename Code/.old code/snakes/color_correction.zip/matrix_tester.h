#ifndef matrix_tester
#define matrix_tester

#define verticalmax 16
#define horizontalmax 8

void create_matrix(char matriz[][verticalmax+1]);
void printmatrix(char matriz[][verticalmax+1]); /*imprime no terminal a matriz de char's*/


#endif
